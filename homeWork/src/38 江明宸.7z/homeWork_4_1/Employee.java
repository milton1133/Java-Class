package homeWork_4_1;

public class Employee {
	private int empno; //員工編號
	private String name; //員工姓名
	private long salary; //薪水
	
	
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getSalary() {
		return salary;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}
	
	
	public String desc() {
		String description = "員工編號："+empno;
        return  description;
		
	}
	
	
	
}

	

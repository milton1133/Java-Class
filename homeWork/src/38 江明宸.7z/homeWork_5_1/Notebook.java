package homeWork_5_1;

public class Notebook extends Product {
	public Notebook(String name, int price) {
		super(name, price);
	}
}
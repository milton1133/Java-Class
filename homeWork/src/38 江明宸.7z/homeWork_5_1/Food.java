package homeWork_5_1;

public class Food extends Product {
	public Food(String name, int price) {
		super(name, price);
	}
}
